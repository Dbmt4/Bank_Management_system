-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 01, 2024 at 12:36 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `internetbanking_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `ib_acc_types`
--

CREATE TABLE `ib_acc_types` (
  `acctype_id` int(20) NOT NULL,
  `acc_type` varchar(200) NOT NULL,
  `description` longtext NOT NULL,
  `rate` varchar(200) NOT NULL,
  `code` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `ib_acc_types`
--

INSERT INTO `ib_acc_types` (`acctype_id`, `acc_type`, `description`, `rate`, `code`) VALUES
(1, 'Savings', '<p>Savings accounts&nbsp;are typically the first official bank account anybody opens. Children may open an account with a parent to begin a pattern of saving. Teenagers open accounts to stash cash earned&nbsp;from a first job&nbsp;or household chores.</p><p>Savings accounts are an excellent place to park&nbsp;emergency cash. Opening a savings account also marks the beginning of your relationship with a financial institution. For example, when joining a credit union, your &ldquo;share&rdquo; or savings account establishes your membership.</p>', '20', 'ACC-CAT-4EZFO'),
(2, ' Retirement', '<p>Retirement accounts&nbsp;offer&nbsp;tax advantages. In very general terms, you get to&nbsp;avoid paying income tax on interest&nbsp;you earn from a savings account or CD each year. But you may have to pay taxes on those earnings at a later date. Still, keeping your money sheltered from taxes may help you over the long term. Most banks offer IRAs (both&nbsp;Traditional IRAs&nbsp;and&nbsp;Roth IRAs), and they may also provide&nbsp;retirement accounts for small businesses</p>', '10', 'ACC-CAT-1QYDV'),
(4, 'Recurring deposit', '<p><strong>Recurring deposit account or RD account</strong> is opened by those who want to save certain amount of money regularly for a certain period of time and earn a higher interest rate.&nbsp;In RD&nbsp;account a&nbsp;fixed amount is deposited&nbsp;every month for a specified period and the total amount is repaid with interest at the end of the particular fixed period.&nbsp;</p><p>The period of deposit is minimum six months and maximum ten years.&nbsp;The interest rates vary&nbsp;for different plans based on the amount one saves and the period of time and also on banks. No withdrawals are allowed from the RD account. However, the bank may allow to close the account before the maturity period.</p><p>These accounts can be opened in single or joint names. Banks are also providing the Nomination facility to the RD account holders.&nbsp;</p>', '15', 'ACC-CAT-VBQLE'),
(5, 'Fixed Deposit Account', '<p>In <strong>Fixed Deposit Account</strong> (also known as <strong>FD Account</strong>), a particular sum of money is deposited in a bank for specific&nbsp;period of time. It&rsquo;s one time deposit and one time take away (withdraw) account.&nbsp;The money deposited in this account can not be withdrawn before the expiry of period.&nbsp;</p><p>However, in case of need,&nbsp; the depositor can ask for closing the fixed deposit prematurely by paying a penalty. The penalty amount varies with banks.</p><p>A high interest rate is paid on fixed deposits. The rate of interest paid for fixed deposit vary according to amount, period and also from bank to bank.</p>', '40', 'ACC-CAT-A86GO'),
(7, 'Current account', '<p><strong>Current account</strong> is mainly for business persons, firms, companies, public enterprises etc and are never used for the purpose of investment or savings.These deposits are the most liquid deposits and there are no limits for number of transactions or the amount of transactions in a day. While, there is no interest paid on amount held in the account, banks charges certain &nbsp;service charges, on such accounts. The current accounts do not have any fixed maturity as these are on continuous basis accounts.</p>', '20', 'ACC-CAT-4O8QW');

-- --------------------------------------------------------

--
-- Table structure for table `ib_admin`
--

CREATE TABLE `ib_admin` (
  `admin_id` int(20) NOT NULL,
  `name` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `number` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `profile_pic` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `ib_admin`
--

INSERT INTO `ib_admin` (`admin_id`, `name`, `email`, `number`, `password`, `profile_pic`) VALUES
(2, 'System Administrator', 'admin@gmail.com', 'iBank-ADM-0516', 'd3a525ad32af27869542c5f89a25f200663008c4', 'admin-icn.png');

-- --------------------------------------------------------

--
-- Table structure for table `ib_bankaccounts`
--

CREATE TABLE `ib_bankaccounts` (
  `account_id` int(20) NOT NULL,
  `acc_name` varchar(200) NOT NULL,
  `account_number` varchar(200) NOT NULL,
  `acc_type` varchar(200) NOT NULL,
  `acc_rates` float NOT NULL,
  `acc_status` varchar(200) NOT NULL,
  `acc_amount` float NOT NULL,
  `client_id` int(11) NOT NULL,
  `client_name` varchar(200) NOT NULL,
  `client_national_id` varchar(200) NOT NULL,
  `client_phone` varchar(10) NOT NULL,
  `client_number` varchar(200) NOT NULL,
  `client_email` varchar(200) NOT NULL,
  `client_adr` varchar(200) NOT NULL,
  `created_at` timestamp(6) NOT NULL DEFAULT current_timestamp(6) ON UPDATE current_timestamp(6)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `ib_bankaccounts`
--

INSERT INTO `ib_bankaccounts` (`account_id`, `acc_name`, `account_number`, `acc_type`, `acc_rates`, `acc_status`, `acc_amount`, `client_id`, `client_name`, `client_national_id`, `client_phone`, `client_number`, `client_email`, `client_adr`, `created_at`) VALUES
(26, 'guna', '947635201', 'Savings ', 20, 'Active', 1010, 17, 'Guna', '2312120', '8328207004', 'iBank-CLIENT-3054', 'Teja@gmail.com', 'ggga', '2024-04-30 22:11:32.491433'),
(27, 'Likhitha', '576184230', 'Savings ', 20, 'Active', 1490, 18, 'Likhitha', '23456785', '7168893908', 'iBank-CLIENT-7301', 'likhitha@gmail.com', '8181 Fanin St', '2024-04-24 14:43:36.508358'),
(28, 'Harshitha', '457092816', 'Savings ', 20, 'Active', 770, 19, 'Harshitha', '2279919', '7132806676', 'iBank-CLIENT-6034', 'harshitha@gmail.com', '2250 Holly hall st', '2024-04-30 22:15:10.886716'),
(29, 'Harshitha_FD', '178349602', 'Fixed Deposit Account ', 40, 'Active', 1000, 19, 'Harshitha', '2279919', '7132806676', 'iBank-CLIENT-6034', 'harshitha@gmail.com', '2250 Holly hall st', '2024-04-23 19:09:58.225983'),
(30, 'Poojitha', '539847026', 'Savings ', 20, 'Active', 950, 20, 'Poojitha', '2311344', '3466380113', 'iBank-CLIENT-9705', 'poojitha@gmail.com', '2250 Holly hall st', '2024-04-30 21:45:19.303113'),
(31, 'harshini', '146832975', 'Savings ', 20, 'Active', 60, 21, 'Harshini', '2316672', '8624105070', 'iBank-CLIENT-0439', 'harshini@gmail.com', '8450 cambridge st', '2024-04-30 22:11:32.494671'),
(32, 'harshini', '458126309', 'Savings ', 20, 'Active', 130, 21, 'Harshini Nimmala', '2316672', '8624105070', 'iBank-CLIENT-0439', 'harshini@gmail.com', '8450 cambridge st', '2024-04-24 14:43:23.084481'),
(34, 'Sanjana', '476318205', 'Current account ', 20, 'Active', 2210, 23, 'Sanjana Ponaganthi', '2314566', '7136534696', 'iBank-CLIENT-4921', 'sanjana@gmail.com', '2345 Bissonet St', '2024-04-30 22:15:10.890140'),
(36, 'mansib', '853127649', 'Savings ', 20, 'Active', 50, 24, 'Mansib ', '2254670', '1231231234', 'iBank-CLIENT-0751', 'mansib@gmail.com', 'Houston', '2024-04-24 15:35:53.720551');

-- --------------------------------------------------------

--
-- Table structure for table `ib_clients`
--

CREATE TABLE `ib_clients` (
  `client_id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `national_id` varchar(200) NOT NULL,
  `phone` int(10) NOT NULL,
  `address` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `profile_pic` varchar(200) NOT NULL,
  `client_number` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `ib_clients`
--

INSERT INTO `ib_clients` (`client_id`, `name`, `national_id`, `phone`, `address`, `email`, `password`, `profile_pic`, `client_number`) VALUES
(17, 'Guna', '2312120', 2147483647, '8182 MedCenter', 'Teja@gmail.com', '4920c064cb1044964395164ebef4e1b247c6be97', '', 'iBank-CLIENT-3054'),
(18, 'Likhitha', '23456785', 2147483647, '8181 Fanin St', 'likhitha@gmail.com', '1af4e773b91da30669fc0b47399f999b8aa5c04a', '', 'iBank-CLIENT-7301'),
(19, 'Harshitha', '2279919', 2147483647, '2250 Holly hall st', 'harshitha@gmail.com', 'fcd08d31b1c186fad3c9571c5a727f07d2a52f13', '', 'iBank-CLIENT-6034'),
(20, 'Poojitha', '2311344', 2147483647, '2250 Holly hall st', 'poojitha@gmail.com', '24b8ce2dbde8f7b9a3b120f41a1f564661eb362e', '', 'iBank-CLIENT-9705'),
(21, 'Harshini Nimmala', '2316672', 2147483647, '8450 cambridge st', 'harshini@gmail.com', 'e07eaefd8da8e05d8a828cca1e4439a0dd90df14', '', 'iBank-CLIENT-0439'),
(22, 'Pavan Kalyan', '123456', 2147483647, '8450 cambridge st', 'pavankalyan@gmail.com', '20f1bf1372ea56a2d81eee00a748e8f45a53ef39', '', 'iBank-CLIENT-3286'),
(23, 'Sanjana Ponaganthi', '2314566', 2147483647, '2345 Bissonet St', 'sanjana@gmail.com', '299c6ad8ad6d0091059efb8d1d68a34051b957be', '', 'iBank-CLIENT-4921'),
(24, 'Mansib ', '2254670', 1231231234, 'Houston', 'mansib@gmail.com', '7f06c04d59bd83605193621e8d0d693bd30cdc9e', '', 'iBank-CLIENT-0751');

-- --------------------------------------------------------

--
-- Table structure for table `ib_notifications`
--

CREATE TABLE `ib_notifications` (
  `notification_id` int(20) NOT NULL,
  `notification_details` text NOT NULL,
  `created_at` timestamp(6) NOT NULL DEFAULT current_timestamp(6) ON UPDATE current_timestamp(6)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `ib_notifications`
--

INSERT INTO `ib_notifications` (`notification_id`, `notification_details`, `created_at`) VALUES
(152, 'Harshitha Has Withdrawn $ 200 From Bank Account 178349602', '2024-04-23 17:24:30.729681'),
(153, 'Guna Has Failed Withdrawal $ 2000 From Bank Account 947635201', '2024-04-23 17:26:16.211560'),
(154, 'Likhitha Has Transfered $ 500 From Bank Account 576184230 To Bank Account 457092816', '2024-04-23 17:27:55.776175'),
(155, 'Harshitha Has Failed to Transfer $ 3000 From Bank Account 457092816 To Bank Account 947635201', '2024-04-23 17:30:54.920943'),
(156, 'Poojitha Has Deposited $ 500 To Bank Account 539847026', '2024-04-23 18:52:01.502033'),
(157, 'Poojitha Has Withdrawn $ 200 From Bank Account 539847026', '2024-04-23 18:55:04.421492'),
(158, 'Poojitha Has Failed Withdrawal $ 1500 From Bank Account 539847026', '2024-04-23 18:55:29.491692'),
(159, 'Likhitha Has Transfered $ 500 From Bank Account 576184230 To Bank Account 539847026', '2024-04-23 18:59:36.922503'),
(160, 'Harshitha Has Transfered $ 200 From Bank Account 457092816 To Bank Account 178349602', '2024-04-23 19:09:58.231304'),
(161, 'Harshitha Has Withdrawn $ 300 From Bank Account 457092816', '2024-04-23 19:30:19.192175'),
(162, 'Harshini Has Deposited $ 100 To Bank Account 146832975', '2024-04-23 20:55:04.111397'),
(163, 'Harshini Has Withdrawn $ 50 From Bank Account 146832975', '2024-04-23 20:55:53.978145'),
(164, 'Harshini Has Failed Withdrawal $ 200 From Bank Account 146832975', '2024-04-23 20:56:59.202628'),
(165, 'Poojitha Has Transfered $ 100 From Bank Account 539847026 To Bank Account 146832975', '2024-04-23 20:58:21.202773'),
(166, 'Harshini Has Transfered $ 50 From Bank Account 146832975 To Bank Account 539847026', '2024-04-23 21:38:16.058793'),
(167, 'Harshini Nimmala Has Deposited $ 30 To Bank Account 458126309', '2024-04-23 21:53:12.954392'),
(168, 'Harshini Has Failed to Transfer $ 500 From Bank Account 146832975 To Bank Account 539847026', '2024-04-23 22:01:39.260020'),
(169, 'Harshini Has Failed to Transfer $ 10000 From Bank Account 146832975 To Bank Account 539847026', '2024-04-23 22:03:43.416448'),
(170, 'Harshini Has Failed to Transfer $ 20000 From Bank Account 146832975 To Bank Account 576184230', '2024-04-23 22:13:38.594424'),
(171, 'Harshini Has Failed to Transfer $ 10000 From Bank Account 146832975 To Bank Account 457092816', '2024-04-23 22:13:51.779960'),
(172, 'Harshini Has Failed to Transfer $ 3500 From Bank Account 146832975 To Bank Account 947635201', '2024-04-23 22:17:29.867643'),
(173, 'Harshini Has Failed to Transfer $ 3500 From Bank Account 146832975 To Bank Account 947635201', '2024-04-23 22:18:34.074221'),
(174, 'Harshini Has Failed to Transfer $ 4500 From Bank Account 146832975 To Bank Account 178349602', '2024-04-23 22:18:47.403840'),
(175, 'Harshini Has Failed to Transfer $ 7000 From Bank Account 146832975 To Bank Account 576184230', '2024-04-23 22:20:25.750580'),
(176, 'Sanjana Ponaganthi Has Deposited $ 2000 To Bank Account 476318205', '2024-04-23 22:34:16.857421'),
(177, 'Harshitha Has Transfered $ 200 From Bank Account 457092816 To Bank Account 476318205', '2024-04-24 14:27:29.383193'),
(178, 'Harshitha Has Failed to Transfer $ 100000 From Bank Account 457092816 To Bank Account 576184230', '2024-04-24 14:27:38.711767'),
(179, 'Guna Has Failed to Transfer $ 35674685 From Bank Account 947635201 To Bank Account Select Receiving Account', '2024-04-24 14:35:51.806068'),
(180, 'Guna Has Failed to Transfer $ 356789 From Bank Account 947635201 To Bank Account Select Receiving Account', '2024-04-24 14:37:32.294399'),
(181, 'Harshitha Has Failed Withdrawal $ 100000 From Bank Account 457092816', '2024-04-24 14:38:04.525414'),
(182, 'Harshitha Has Failed Withdrawal $ 10000 From Bank Account 457092816', '2024-04-24 14:39:01.790098'),
(183, 'Harshini Nimmala Has Deposited $ 100 To Bank Account 458126309', '2024-04-24 14:43:23.093817'),
(184, 'Likhitha Has Withdrawn $ 10 From Bank Account 576184230', '2024-04-24 14:43:36.514524'),
(185, 'Harshitha Has Transfered $ 20 From Bank Account 457092816 To Bank Account 947635201', '2024-04-24 14:43:52.202300'),
(186, 'Likhitha Has Failed Withdrawal $ 1000021265 From Bank Account 576184230', '2024-04-24 14:44:22.446538'),
(187, 'Guna Has Failed to Transfer $ 1156015624962 From Bank Account 947635201 To Bank Account 947635201', '2024-04-24 14:44:39.644860'),
(188, 'Harshini Has Transfered $ 50 From Bank Account 146832975 To Bank Account 853127649', '2024-04-24 15:35:53.727658'),
(189, 'Poojitha Has Deposited $ 200 To Bank Account 539847026', '2024-04-30 21:45:19.310745'),
(190, 'Guna Has Transfered $ 10 From Bank Account 947635201 To Bank Account 146832975', '2024-04-30 22:11:32.501641'),
(191, 'Harshitha Has Transfered $ 10 From Bank Account 457092816 To Bank Account 476318205', '2024-04-30 22:15:10.898782');

-- --------------------------------------------------------

--
-- Table structure for table `ib_staff`
--

CREATE TABLE `ib_staff` (
  `staff_id` int(20) NOT NULL,
  `name` varchar(200) NOT NULL,
  `staff_number` varchar(200) NOT NULL,
  `phone` varchar(10) NOT NULL,
  `email` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `sex` varchar(200) NOT NULL,
  `profile_pic` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `ib_staff`
--

INSERT INTO `ib_staff` (`staff_id`, `name`, `staff_number`, `phone`, `email`, `password`, `sex`, `profile_pic`) VALUES
(3, 'Staff ', 'iBank-STAFF-6785', '0704975742', 'staff@gmail.com', '2e519e5786d258adc86559f85967d79065d22ccf', 'Male', 'user-profile-min.png'),
(106, 'staff2', 'iBank-STAFF-7365', '7848469526', 'staff2@gmail.com', '2e519e5786d258adc86559f85967d79065d22ccf', 'Female', '');

-- --------------------------------------------------------

--
-- Table structure for table `ib_systemsettings`
--

CREATE TABLE `ib_systemsettings` (
  `id` int(20) NOT NULL,
  `sys_name` longtext NOT NULL,
  `sys_tagline` longtext NOT NULL,
  `sys_logo` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `ib_systemsettings`
--

INSERT INTO `ib_systemsettings` (`id`, `sys_name`, `sys_tagline`, `sys_logo`) VALUES
(1, 'Internet Banking', 'Financial success at every service we offer.', 'istockphoto-1202705835-612x612.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `ib_transactions`
--

CREATE TABLE `ib_transactions` (
  `tr_id` int(20) NOT NULL,
  `tr_code` varchar(200) NOT NULL,
  `account_id` int(20) NOT NULL,
  `acc_name` varchar(200) NOT NULL,
  `account_number` varchar(200) NOT NULL,
  `acc_type` varchar(200) NOT NULL,
  `acc_amount` float NOT NULL,
  `tr_type` varchar(200) NOT NULL,
  `tr_status` varchar(200) NOT NULL,
  `client_id` varchar(200) NOT NULL,
  `client_name` varchar(200) NOT NULL,
  `client_national_id` varchar(200) NOT NULL,
  `transaction_amt` float NOT NULL,
  `client_phone` int(10) NOT NULL,
  `receiving_acc_no` varchar(200) NOT NULL,
  `created_at` timestamp(6) NOT NULL DEFAULT current_timestamp(6) ON UPDATE current_timestamp(6),
  `receiving_acc_name` varchar(200) NOT NULL,
  `receiving_acc_holder` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `ib_transactions`
--

INSERT INTO `ib_transactions` (`tr_id`, `tr_code`, `account_id`, `acc_name`, `account_number`, `acc_type`, `acc_amount`, `tr_type`, `tr_status`, `client_id`, `client_name`, `client_national_id`, `transaction_amt`, `client_phone`, `receiving_acc_no`, `created_at`, `receiving_acc_name`, `receiving_acc_holder`) VALUES
(97, 'cJ1YKBnOWgNyt4sbLzwZ', 27, 'Likhitha', '576184230', 'Savings ', 2400, 'Deposit', 'Success ', '18', 'Likhitha', '23456785', 2400, 2147483647, '', '2024-04-23 16:54:07.280267', '', ''),
(104, 'YBxozcNSVR0gtD7ilqsK', 26, 'guna', '947635201', 'Savings ', 800, 'Deposit', 'Success ', '17', 'Guna', '2312120', 800, 2147483647, '', '2024-04-23 16:53:44.401053', '', ''),
(159, 'ygT1O0voBEUPJ2X9zeDL', 27, 'Likhitha', '576184230', 'Savings ', 2200, 'Transfer', 'Success ', '18', 'Likhitha', '23456785', 200, 2147483647, '947635201', '2024-04-23 16:55:50.165370', 'guna', 'Guna'),
(160, 'rGFjeZPfn4NygdvJ3S5B', 26, 'guna', '947635201', 'Savings ', 900, 'Transfer', 'Success ', '17', 'Guna', '2312120', 100, 2147483647, '576184230', '2024-04-23 16:57:40.176351', 'Likhitha', 'Likhitha'),
(161, 'kUjCzwdKmcP2ptOHqoT8', 26, 'guna', '947635201', 'Savings ', 900, 'Transfer', 'Failed', '17', 'Guna', '2312120', 1000, 2147483647, '', '2024-04-23 17:04:48.558256', '', ''),
(162, 'HZEv3hJ9uRBSF2txOn7i', 28, 'Harshitha', '457092816', 'Savings ', 500, 'Deposit', 'Success ', '19', 'Harshitha', '2279919', 500, 2147483647, '', '2024-04-23 17:16:15.681660', '', ''),
(163, 'qGATBeSbPugICXK1pjEF', 29, 'Harshitha_FD', '178349602', 'Fixed Deposit Account ', 800, 'Deposit', 'Success ', '19', 'Harshitha', '2279919', 800, 2147483647, '', '2024-04-23 17:16:45.014955', '', ''),
(164, 'yE0JCTwo4mj6nDOicNWe', 28, 'Harshitha', '457092816', 'Savings ', 300, 'Transfer', 'Success ', '19', 'Harshitha', '2279919', 200, 2147483647, '178349602', '2024-04-23 17:17:11.076530', 'Harshitha_FD', 'Harshitha'),
(165, 'okyVsAS7dgNH9OLQceJX', 27, 'Likhitha', '576184230', 'Savings ', 2500, 'Deposit', 'Success ', '18', 'Likhitha', '23456785', 200, 2147483647, '', '2024-04-23 17:21:36.894758', '', ''),
(166, 'CwGZqQmDV80zyTXFA47U', 28, 'Harshitha', '457092816', 'Savings ', 1000, 'Deposit', 'Success ', '19', 'Harshitha', '2279919', 700, 2147483647, '', '2024-04-23 17:22:49.200823', '', ''),
(167, '4wLsEObd1yKDtS6fjcTZ', 26, 'guna', '947635201', 'Savings ', 1000, 'Deposit', 'Success ', '17', 'Guna', '2312120', 100, 2147483647, '', '2024-04-23 17:23:28.886811', '', ''),
(168, 'gYntNWZLE9cDJUBosuIj', 29, 'Harshitha_FD', '178349602', 'Fixed Deposit Account ', 800, 'Withdrawal', 'Success ', '19', 'Harshitha', '2279919', 200, 2147483647, '', '2024-04-23 17:24:30.726548', '', ''),
(169, 'z6BNVDiAZJGg0LREPTWs', 26, 'guna', '947635201', 'Savings ', 1000, 'Withdrawal', 'Failed', '17', 'Guna', '2312120', 2000, 2147483647, '', '2024-04-23 17:26:16.208963', '', ''),
(170, '2phOwWzNXGVF6TKg7yfC', 27, 'Likhitha', '576184230', 'Savings ', 2000, 'Transfer', 'Success ', '18', 'Likhitha', '23456785', 500, 2147483647, '457092816', '2024-04-23 17:27:55.772783', 'Harshitha', 'Harshitha'),
(171, '40waiWqd2jrFhnsfD1kE', 28, 'Harshitha', '457092816', 'Savings ', 1500, 'Transfer', 'Failed', '19', 'Harshitha', '2279919', 3000, 2147483647, '', '2024-04-23 17:30:54.917538', '', ''),
(172, 'AJXZ2kiuRm7oN8KxPefh', 30, 'Poojitha', '539847026', 'Savings ', 500, 'Deposit', 'Success ', '20', 'Poojitha', '2311344', 500, 2147483647, '', '2024-04-23 18:52:01.499015', '', ''),
(173, 'mbGB7HngXyfkOP3thz5e', 30, 'Poojitha', '539847026', 'Savings ', 300, 'Withdrawal', 'Success ', '20', 'Poojitha', '2311344', 200, 2147483647, '', '2024-04-23 18:55:04.419490', '', ''),
(174, 'nx2WM4ido86DV3IvXtmk', 30, 'Poojitha', '539847026', 'Savings ', 300, 'Withdrawal', 'Failed', '20', 'Poojitha', '2311344', 1500, 2147483647, '', '2024-04-23 18:55:29.489162', '', ''),
(175, 'soaMx32S71FyHzbAlQLh', 27, 'Likhitha', '576184230', 'Savings ', 1500, 'Transfer', 'Success ', '18', 'Likhitha', '23456785', 500, 2147483647, '539847026', '2024-04-23 18:59:36.920406', 'Poojitha', 'Poojitha'),
(176, 'ZOa9gMcKxCLjkosvXDbA', 28, 'Harshitha', '457092816', 'Savings ', 1300, 'Transfer', 'Success ', '19', 'Harshitha', '2279919', 200, 2147483647, '178349602', '2024-04-23 19:09:58.228428', 'Harshitha_FD', 'Harshitha'),
(177, 'yqEBj8XhJKZMGlIRADc5', 28, 'Harshitha', '457092816', 'Savings ', 1000, 'Withdrawal', 'Success ', '19', 'Harshitha', '2279919', 300, 2147483647, '', '2024-04-23 19:30:19.189775', '', ''),
(178, 'pJAGBTV2oiMj3y0XwNsK', 31, 'harshini', '146832975', 'Savings ', 100, 'Deposit', 'Success ', '21', 'Harshini', '2316672', 100, 2147483647, '', '2024-04-23 20:55:04.106033', '', ''),
(179, '3MnLXZUqP7BrDsxa01Qt', 31, 'harshini', '146832975', 'Savings ', 50, 'Withdrawal', 'Success ', '21', 'Harshini', '2316672', 50, 2147483647, '', '2024-04-23 20:55:53.974195', '', ''),
(180, 'lO8iwXuzYtMcS67KA3Qp', 31, 'harshini', '146832975', 'Savings ', 50, 'Withdrawal', 'Failed', '21', 'Harshini', '2316672', 200, 2147483647, '', '2024-04-23 20:56:59.199451', '', ''),
(181, '0njl4dtuQzfMpBmTDvwX', 30, 'Poojitha', '539847026', 'Savings ', 700, 'Transfer', 'Success ', '20', 'Poojitha', '2311344', 100, 2147483647, '146832975', '2024-04-23 20:58:21.199094', 'harshini', 'Harshini'),
(182, 'RYom1DPrBxNM6zZGqSa5', 31, 'harshini', '146832975', 'Savings ', 100, 'Transfer', 'Success ', '21', 'Harshini', '2316672', 50, 2147483647, '539847026', '2024-04-23 21:38:16.055992', 'Poojitha', 'Poojitha'),
(183, 'beZpjLwmIJ8oMRql9vQE', 32, 'harshini', '458126309', 'Savings ', 30, 'Deposit', 'Success ', '21', 'Harshini Nimmala', '2316672', 30, 2147483647, '', '2024-04-23 21:53:12.948050', '', ''),
(184, '03n6YqblFwsZjV9GfOBE', 31, 'harshini', '146832975', 'Savings ', 100, 'Transfer', 'Failed', '21', 'Harshini', '2316672', 500, 2147483647, '', '2024-04-23 22:01:39.256435', '', ''),
(185, 'iszMOu8fDmx4rVZnplEd', 31, 'harshini', '146832975', 'Savings ', 100, 'Transfer', 'Failed', '21', 'Harshini', '2316672', 10000, 2147483647, '', '2024-04-23 22:03:43.414179', '', ''),
(186, '3SdjVXaTJwx4O5ZDKvoB', 31, 'harshini', '146832975', 'Savings ', 100, 'Transfer', 'Failed', '21', 'Harshini', '2316672', 20000, 2147483647, '', '2024-04-23 22:13:38.590650', '', ''),
(187, 'Bx7aCsIVqYyAW9UfODPb', 31, 'harshini', '146832975', 'Savings ', 100, 'Transfer', 'Failed', '21', 'Harshini', '2316672', 10000, 2147483647, '', '2024-04-23 22:13:51.775908', '', ''),
(188, '4z9VdolCvH3pNyfArw1m', 31, 'harshini', '146832975', 'Savings ', 100, 'Transfer', 'Failed', '21', 'Harshini', '2316672', 3500, 2147483647, '', '2024-04-23 22:17:29.863010', '', ''),
(190, '7bCAZz4ojfdFuc0UxeV5', 31, 'harshini', '146832975', 'Savings ', 100, 'Transfer', 'Failed', '21', 'Harshini', '2316672', 4500, 2147483647, '', '2024-04-23 22:18:47.400813', '', ''),
(191, 'xGeoAlZfTQ9UCvSr5gsW', 31, 'harshini', '146832975', 'Savings ', 100, 'Transfer', 'Failed', '21', 'Harshini', '2316672', 7000, 2147483647, '', '2024-04-23 22:20:25.746697', '', ''),
(192, '6KQcIk4J2bmie97AxgM1', 34, 'Sanjana', '476318205', 'Current account ', 2000, 'Deposit', 'Success ', '23', 'Sanjana Ponaganthi', '2314566', 2000, 2147483647, '', '2024-04-23 22:34:16.853157', '', ''),
(193, 'z8FIqjafbQ1BJ6iTOEpU', 28, 'Harshitha', '457092816', 'Savings ', 800, 'Transfer', 'Success ', '19', 'Harshitha', '2279919', 200, 2147483647, '476318205', '2024-04-24 14:27:29.381099', 'Sanjana', 'Sanjana Ponaganthi'),
(194, '4TdLecn5Pv7DWJhuSksA', 28, 'Harshitha', '457092816', 'Savings ', 800, 'Transfer', 'Failed', '19', 'Harshitha', '2279919', 100000, 2147483647, '', '2024-04-24 14:27:38.708792', '', ''),
(195, 'ucS2is7wrv36WI0YbqaE', 26, 'guna', '947635201', 'Savings ', 1000, 'Transfer', 'Failed', '17', 'Guna', '2312120', 35674700, 2147483647, '', '2024-04-24 14:35:51.802478', '', ''),
(197, 'UdSr05eKo1MB8wV76bDA', 26, 'guna', '947635201', 'Savings ', 1000, 'Transfer', 'Failed', '17', 'Guna', '2312120', 356789, 2147483647, '', '2024-04-24 14:37:32.291633', '', ''),
(198, 'T2HIPhNXQFCsakcpqewK', 28, 'Harshitha', '457092816', 'Savings ', 800, 'Withdrawal', 'Failed', '19', 'Harshitha', '2279919', 100000, 2147483647, '', '2024-04-24 14:38:04.516173', '', ''),
(200, 'supdC7ZPJ32TAkXOwGyl', 28, 'Harshitha', '457092816', 'Savings ', 800, 'Withdrawal', 'Failed', '19', 'Harshitha', '2279919', 10000, 2147483647, '', '2024-04-24 14:39:01.787534', '', ''),
(201, 'nTCgviXQysbfExa2juhk', 32, 'harshini', '458126309', 'Savings ', 130, 'Deposit', 'Success ', '21', 'Harshini Nimmala', '2316672', 100, 2147483647, '', '2024-04-24 14:43:23.091201', '', ''),
(202, 'XRQkOCeKz3MBHsL0d1va', 27, 'Likhitha', '576184230', 'Savings ', 1490, 'Withdrawal', 'Success ', '18', 'Likhitha', '23456785', 10, 2147483647, '', '2024-04-24 14:43:36.511897', '', ''),
(203, 'IHsYKvwfyCUM15tqdDLc', 28, 'Harshitha', '457092816', 'Savings ', 780, 'Transfer', 'Success ', '19', 'Harshitha', '2279919', 20, 2147483647, '947635201', '2024-04-24 14:43:52.200074', 'guna', 'Guna'),
(204, 'DSIC4hzsOE9qu3tAv6Me', 27, 'Likhitha', '576184230', 'Savings ', 1490, 'Withdrawal', 'Failed', '18', 'Likhitha', '23456785', 1000020000, 2147483647, '', '2024-04-24 14:44:22.444024', '', ''),
(205, 'tDm5E6h4wRyHsrUQTJfX', 26, 'guna', '947635201', 'Savings ', 1020, 'Transfer', 'Failed', '17', 'Guna', '2312120', 1156020000000, 2147483647, '', '2024-04-24 14:44:39.640712', '', ''),
(206, 'V48J7QPeDfnGHFk6o1qu', 31, 'harshini', '146832975', 'Savings ', 50, 'Transfer', 'Success ', '21', 'Harshini', '2316672', 50, 2147483647, '853127649', '2024-04-24 15:35:53.724304', 'mansib', 'Mansib '),
(207, 'iAopVyczndQkLJW1UvPa', 30, 'Poojitha', '539847026', 'Savings ', 950, 'Deposit', 'Success ', '20', 'Poojitha', '2311344', 200, 2147483647, '', '2024-04-30 21:45:19.307165', '', ''),
(208, 'B0GhaYoM2i6OcAVr7JQw', 26, 'guna', '947635201', 'Savings ', 1010, 'Transfer', 'Success ', '17', 'Guna', '2312120', 10, 2147483647, '146832975', '2024-04-30 22:11:32.498367', 'harshini', 'Harshini'),
(209, 'V7o3Jn1yLFiPSjCOuRdr', 28, 'Harshitha', '457092816', 'Savings ', 770, 'Transfer', 'Success ', '19', 'Harshitha', '2279919', 10, 2147483647, '476318205', '2024-04-30 22:15:10.895581', 'Sanjana', 'Sanjana Ponaganthi');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ib_acc_types`
--
ALTER TABLE `ib_acc_types`
  ADD PRIMARY KEY (`acctype_id`),
  ADD UNIQUE KEY `code` (`code`),
  ADD UNIQUE KEY `acc_type` (`acc_type`);

--
-- Indexes for table `ib_admin`
--
ALTER TABLE `ib_admin`
  ADD PRIMARY KEY (`admin_id`),
  ADD UNIQUE KEY `number` (`number`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `ib_bankaccounts`
--
ALTER TABLE `ib_bankaccounts`
  ADD PRIMARY KEY (`account_id`),
  ADD UNIQUE KEY `account_number` (`account_number`),
  ADD KEY `fk_client_id` (`client_id`),
  ADD KEY `fk_client_number` (`client_number`),
  ADD KEY `fk_client_national_id` (`client_national_id`),
  ADD KEY `fk_acc_type` (`acc_type`);

--
-- Indexes for table `ib_clients`
--
ALTER TABLE `ib_clients`
  ADD PRIMARY KEY (`client_id`),
  ADD UNIQUE KEY `national_id` (`national_id`),
  ADD UNIQUE KEY `client_number` (`client_number`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `ib_notifications`
--
ALTER TABLE `ib_notifications`
  ADD PRIMARY KEY (`notification_id`);

--
-- Indexes for table `ib_staff`
--
ALTER TABLE `ib_staff`
  ADD PRIMARY KEY (`staff_id`),
  ADD UNIQUE KEY `staff_number` (`staff_number`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `ib_systemsettings`
--
ALTER TABLE `ib_systemsettings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ib_transactions`
--
ALTER TABLE `ib_transactions`
  ADD PRIMARY KEY (`tr_id`),
  ADD UNIQUE KEY `tr_code` (`tr_code`),
  ADD KEY `fk_account_id` (`account_id`),
  ADD KEY `fk_account_number` (`account_number`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ib_acc_types`
--
ALTER TABLE `ib_acc_types`
  MODIFY `acctype_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `ib_admin`
--
ALTER TABLE `ib_admin`
  MODIFY `admin_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=57;

--
-- AUTO_INCREMENT for table `ib_bankaccounts`
--
ALTER TABLE `ib_bankaccounts`
  MODIFY `account_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `ib_clients`
--
ALTER TABLE `ib_clients`
  MODIFY `client_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `ib_notifications`
--
ALTER TABLE `ib_notifications`
  MODIFY `notification_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=192;

--
-- AUTO_INCREMENT for table `ib_staff`
--
ALTER TABLE `ib_staff`
  MODIFY `staff_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=107;

--
-- AUTO_INCREMENT for table `ib_systemsettings`
--
ALTER TABLE `ib_systemsettings`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `ib_transactions`
--
ALTER TABLE `ib_transactions`
  MODIFY `tr_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=210;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `ib_bankaccounts`
--
ALTER TABLE `ib_bankaccounts`
  ADD CONSTRAINT `fk_acc_type` FOREIGN KEY (`acc_type`) REFERENCES `ib_acc_types` (`acc_type`),
  ADD CONSTRAINT `fk_client_id` FOREIGN KEY (`client_id`) REFERENCES `ib_clients` (`client_id`),
  ADD CONSTRAINT `fk_client_national_id` FOREIGN KEY (`client_national_id`) REFERENCES `ib_clients` (`national_id`),
  ADD CONSTRAINT `fk_client_number` FOREIGN KEY (`client_number`) REFERENCES `ib_clients` (`client_number`);

--
-- Constraints for table `ib_transactions`
--
ALTER TABLE `ib_transactions`
  ADD CONSTRAINT `fk_account_id` FOREIGN KEY (`account_id`) REFERENCES `ib_bankaccounts` (`account_id`),
  ADD CONSTRAINT `fk_account_number` FOREIGN KEY (`account_number`) REFERENCES `ib_bankaccounts` (`account_number`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
