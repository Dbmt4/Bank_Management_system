<?php
    $dbuser="root";
    $dbpass="";
    $host="localhost";
    $db="internetbanking_db";
    $mysqli=new mysqli($host,$dbuser, $dbpass, $db);
